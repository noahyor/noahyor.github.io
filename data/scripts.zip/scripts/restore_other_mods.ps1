Write-Output "Restoring Mods..."
Move-Item ~\AppData\Roaming\.minecraft\mods ~\AppData\Roaming\.minecraft\.CCraft\ccraft_mods
Move-Item ~\AppData\Roaming\.minecraft\.CCraft\mods_old ~\AppData\Roaming\.minecraft\mods
Write-Output "Done!"
pause
Remove-Item .\data\scripts\restore_other_mods.ps1