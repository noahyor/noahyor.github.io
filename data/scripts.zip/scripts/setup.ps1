Write-Host "Install Minecraft: Java Edition, then come back here."
Write-Host "If you already have it installed, continue."
Write-Host "If you wish to terminate the program,"
Write-Host "you can do so at any time by pressing Ctrl-c"
pause
Write-Host "Downloading Forge Installer..."
Invoke-WebRequest https://maven.minecraftforge.net/net/minecraftforge/forge/1.18.2-40.2.10/forge-1.18.2-40.2.10-installer.jar -OutFile .\forge-1.18.2-40.2.10-installer.jar
Write-Host "Done!"
Write-Host "Installing Forge..."
Write-Host "Please press 'OK' on the next screen."
pause
java -jar .\forge-1.18.2-40.2.10-installer.jar
Write-Host "Moving files around..."
Start-Sleep 2
Remove-Item .\forge-1.18.2-40.2.10-installer.jar
Remove-Item .\installer.log
$null = New-Item ~\AppData\Roaming\.minecraft\.CCraft -ItemType Directory
if (Test-Path ~\AppData\Roaming\.minecraft\mods\*.jar) {
    Write-Host "Previously used mods have been detected."
    if (!(Test-Path ~\AppData\Roaming\.minecraft\.CCraft\mods_old)) {
        $null = New-Item ~\AppData\Roaming\.minecraft\.CCraft\mods_old -ItemType Directory
    }
    Move-Item "~\AppData\Roaming\.minecraft\mods\*.jar" "~\AppData\Roaming\.minecraft\.CCraft\mods_old\*.jar"
    Write-Host "Other mods have been moved to ~\AppData\Roaming\.minecraft\.CCraft\mods_old\ ."
    Write-Host "To restore them while not playing CCraft, use restore_other_mods.ps1"
}
Copy-Item ".\data\mods\*.jar" "~\AppData\Roaming\.minecraft\mods\*.jar"
Write-Host "Setup is now complete."
Write-Host "To play CCraft, open the Minecraft Launcher, then in the dropdown next to the Play button, select Forge."
Write-Host "It may take a few minutes to load. Please be patient."
pause
Copy-Item .\data\scripts\restore_other_mods.ps1 .\
Remove-Item .\setup.ps1
