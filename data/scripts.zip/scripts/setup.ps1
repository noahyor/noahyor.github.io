Write-Host "Install Minecraft: Java Edition, then come back here."
Write-Host "If you already have it installed, continue."
Write-Host "If you wish to terminate the program,"
Write-Host "you can do so at any time by pressing Ctrl-c"
pause
Write-Host "Downloading NeoForge Installer..."
Invoke-WebRequest https://maven.neoforged.net/releases/net/neoforged/forge/1.20.1-47.1.106/forge-1.20.1-47.1.106-installer.jar -OutFile ".\forge-1.20.1-47.1.106-installer.jar"
Write-Host "Done!"
Write-Host "Installing Forge..."
Write-Host "Please press 'OK' on the next screen."
pause
java -jar .\forge-1.20.1-47.1.106-installer.jar
Write-Host "Moving files around..."
Start-Sleep 2
Remove-Item .\forge-1.20.1-47.1.106-installer.jar
$null = New-Item ~\AppData\Roaming\.minecraft\.CCraft -ItemType Directory
if (Test-Path ~\AppData\Roaming\.minecraft\mods\*.jar) {
    Write-Host "Previously used mods have been detected."
    if (!(Test-Path ~\AppData\Roaming\.minecraft\.CCraft\mods_old)) {
        $null = New-Item ~\AppData\Roaming\.minecraft\.CCraft\mods_old -ItemType Directory
    }
    Move-Item "~\AppData\Roaming\.minecraft\mods\*.jar" "~\AppData\Roaming\.minecraft\.CCraft\mods_old\"
    Write-Host "Other mods have been moved to ~\AppData\Roaming\.minecraft\.CCraft\mods_old\ ."
    Write-Host "To restore them while not playing CCraft, use restore_other_mods.ps1"
} elseif (!(Test-Path ~\AppData\Roaming\.minecraft\mods\)) {
    $null = New-Item ~\AppData\Roaming\.minecraft\mods\ -ItemType Directory
}
Copy-Item ".\data\mods\*.jar" "~\AppData\Roaming\.minecraft\mods\"
if (!(Test-Path ~\AppData\Roaming\.minecraft\shaderpacks\)) {
    $null = New-Item ~\AppData\Roaming\.minecraft\shaderpacks\ -ItemType Directory
}
Copy-Item ".\data\shaderpacks\*.zip" "~\AppData\Roaming\.minecraft\shaderpacks\"
Write-Host "Setup is now complete."
Write-Warning "However, it is highly recomended to give Minecraft 4 Gigabytes of RAM."
Write-Host "To do so, open the Installations tab in the launcher and select Forge."
Write-Host "Then, open the 'More Options' dropdown and change the part near the begining from -Xmx2G to -Xmx4G ."
Write-Host "To play CCraft, open the Minecraft Launcher, then in the dropdown next to the Play button, select Forge."
Write-Host "It will take a minute or two to load. Please be patient."
pause
Copy-Item .\data\scripts\restore_other_mods.ps1 .\
Remove-Item .\setup.ps1
